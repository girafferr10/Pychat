# deck.py
import random

class Deck:
    def __init__(self, num_decks=1):
        """
        Initialize a deck (or multiple decks).
        num_decks = how many standard 52-card decks to combine.
        """
        self.num_decks = num_decks
        self.cards = []
        self._build_deck()

    def _build_deck(self):
        ranks = ["A", "2", "3", "4", "5", "6", "7",
                 "8", "9", "10", "J", "Q", "K"]
        suits = ["♠", "♥", "♦", "♣"]
        self.cards = [f"{r}{s}" for r in ranks for s in suits] * self.num_decks
        random.shuffle(self.cards)

    def shuffle(self):
        """Shuffle the deck."""
        random.shuffle(self.cards)

    def draw(self):
        """Draw a card from the deck. If empty, rebuild and shuffle."""
        if not self.cards:
            self._build_deck()
        return self.cards.pop()

    def remaining(self):
        """Return how many cards are left in the deck."""
        return len(self.cards)


# Quick test
if __name__ == "__main__":
    deck = Deck()
    print("Deck created with", deck.remaining(), "cards.")
    print("Drawing 5 cards:")
    for _ in range(5):
        print(deck.draw())
    print("Remaining cards:", deck.remaining())

