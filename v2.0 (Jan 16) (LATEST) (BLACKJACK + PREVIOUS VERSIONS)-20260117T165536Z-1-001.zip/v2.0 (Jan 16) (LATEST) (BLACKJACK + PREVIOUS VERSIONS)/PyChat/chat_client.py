import asyncio
import threading
import tkinter as tk
from tkinter import simpledialog, ttk
import websockets
import json

from blackjack_ui import BlackjackUI

PORT = 8765
DEFAULT_IP = "localhost"

class ChatClient:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("PyChat")

        ip_input = simpledialog.askstring("Server IP", "Enter server IP (leave blank for localhost):")
        self.server_ip = (ip_input or "").strip() or DEFAULT_IP
        self.server_uri = f"ws://{self.server_ip}:{PORT}"

        self.username = simpledialog.askstring("Username", "Enter your username:") or "Anonymous"

        # Top bar
        top_frame = tk.Frame(root)
        self.ip_label = tk.Label(top_frame, text=f"Server IP: {self.server_ip}")
        self.ip_label.pack(side=tk.LEFT, padx=5)
        self.username_label = tk.Label(top_frame, text=f"Username: {self.username}")
        self.username_label.pack(side=tk.LEFT, padx=5)
        tk.Button(top_frame, text="Set Username", command=self.change_username).pack(side=tk.LEFT, padx=5)
        top_frame.pack(pady=(10, 0), anchor="w")

        # Notebook
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(side="right", fill="both", expand=True)
        self.notebook.enable_traversal()
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_change)

        self.tabs = {}

        # Add "+" tab FIRST
        self.plus_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.plus_tab, text="+")

        # Add initial Chat tab
        self.add_chat_tab()

        # Asyncio setup
        self.loop = asyncio.new_event_loop()
        self.websocket = None
        self.connected = False
        self.stopping = False
        threading.Thread(target=self.loop.run_forever, daemon=True).start()
        self.connect()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------- Tab Management ----------

    def on_tab_change(self, event):
        selected = self.notebook.select()
        if self.notebook.tab(selected, "text") == "+":
            self.add_blank_tab()

    def add_blank_tab(self):
        frame = ttk.Frame(self.notebook)
        idx = self.notebook.index(self.plus_tab)
        self.notebook.insert(idx, frame, text="New Tab")
        self.notebook.select(frame)

        label = tk.Label(frame, text="Pick a tab type:", font=("Arial", 12))
        label.pack(pady=10)

        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="Chat", command=lambda: self.replace_with_chat(frame)).pack(side="left", padx=5)
        tk.Button(btn_frame, text="Blackjack", command=lambda: self.replace_with_blackjack(frame)).pack(side="left", padx=5)

    def replace_with_chat(self, frame):
        if "chat" in self.tabs:
            self.notebook.forget(frame)
            self.notebook.select(self.tabs["chat"]["frame"])
            return
        idx = self.notebook.index(frame)
        self.notebook.forget(frame)
        self.add_chat_tab(idx)

    def replace_with_blackjack(self, frame):
        if "blackjack" in self.tabs:
            self.notebook.forget(frame)
            self.notebook.select(self.tabs["blackjack"]["frame"])
            return
        idx = self.notebook.index(frame)
        self.notebook.forget(frame)
        self.add_blackjack_tab(idx)

    def add_chat_tab(self, idx=None):
        frame = ttk.Frame(self.notebook)
        if idx is None:
            idx = self.notebook.index(self.plus_tab)
        self.notebook.insert(idx, frame, text="Chat")

        chat_box = tk.Text(frame, wrap="word", state="disabled", height=20, bg="black", fg="white")
        chat_box.pack(fill="both", expand=True, padx=10, pady=10)

        entry_frame = ttk.Frame(frame)
        entry_frame.pack(fill="x", padx=10, pady=5)
        entry = tk.Entry(entry_frame)
        entry.pack(side="left", fill="x", expand=True)
        send_btn = ttk.Button(entry_frame, text="Send", command=lambda: self.send_message(entry, chat_box))
        send_btn.pack(side="right")

        close_btn = ttk.Button(frame, text="Close Tab", command=lambda: self.close_tab("chat"))
        close_btn.pack(pady=5)

        self.tabs["chat"] = {"frame": frame, "chat_box": chat_box, "entry": entry}

    def add_blackjack_tab(self, idx=None):
        ui = BlackjackUI(self.notebook, self.websocket, self.loop, username=self.username, spectator=False)
        frame = ui.frame
        if idx is None:
            idx = self.notebook.index(self.plus_tab)
        self.notebook.insert(idx, frame, text="Blackjack")

        close_btn = ttk.Button(frame, text="Close Tab", command=lambda: self.close_tab("blackjack"))
        close_btn.pack(pady=5)

        self.tabs["blackjack"] = {"frame": frame, "ui": ui}

        payload = {"type": "bj_join", "name": self.username}
        asyncio.run_coroutine_threadsafe(self.websocket.send(json.dumps(payload)), self.loop)

    def close_tab(self, key):
        if key in self.tabs:
            frame = self.tabs[key]["frame"]
            self.notebook.forget(frame)
            del self.tabs[key]

    # ---------- Networking ----------

    def connect(self):
        def schedule():
            asyncio.ensure_future(self._connect(), loop=self.loop)
        self.loop.call_soon_threadsafe(schedule)

    async def _connect(self):
        while not self.stopping:
            try:
                self.write_chat(f"[SYSTEM] Connecting to {self.server_ip}:{PORT}...")
                self.websocket = await websockets.connect(self.server_uri)
                self.connected = True
                self.write_chat(f"[SYSTEM] Connected to {self.server_ip}:{PORT}")
                asyncio.ensure_future(self._receive_messages(), loop=self.loop)
                return
            except Exception as e:
                self.connected = False
                self.write_chat(f"[SYSTEM] Failed to connect ({e}). Retrying in 2s...")
                await asyncio.sleep(2)

    async def _receive_messages(self):
        try:
            async for message in self.websocket:
                data = json.loads(message)
                self.handle_server_message(data)
        except Exception as e:
            if not self.stopping:
                self.write_chat(f"[SYSTEM] Disconnected ({e}). Reconnecting...")
        finally:
            self.connected = False
            if not self.stopping:
                await self._connect()

    def handle_server_message(self, data):
        msg_type = data.get("type")
        if msg_type == "chat" and "chat" in self.tabs:
            chat_box = self.tabs["chat"]["chat_box"]
            chat_box.config(state="normal")
            chat_box.insert("end", f"{data['from']}: {data['text']}\n")
            chat_box.config(state="disabled")
            chat_box.see("end")

        elif msg_type in ["bj_chat", "bj_state"] and "blackjack" in self.tabs:
            self.tabs["blackjack"]["ui"].handle_server_message(data)

    # ---------- Sending ----------

    def send_message(self, entry, chat_box):
        msg = entry.get().strip()
        if not msg:
            return
        # ✅ Filter out accidental username prefix
        if msg.startswith(f"{self.username}:"):
            msg = msg[len(self.username)+1:].strip()
        entry.delete(0, tk.END)
        payload = {"type": "chat", "text": msg}
        asyncio.run_coroutine_threadsafe(self.websocket.send(json.dumps(payload)), self.loop)

    # ---------- GUI helpers ----------

    def write_chat(self, text: str):
        def append():
            if "chat" in self.tabs:
                chat_box = self.tabs["chat"]["chat_box"]
                chat_box.config(state="normal")
                chat_box.insert("end", text + "\n")
                chat_box.config(state="disabled")
                chat_box.see("end")
        self.root.after(0, append)

    def change_username(self):
        new = simpledialog.askstring("Change Username", "Enter new username:")
        if new:
            self.username = new
            self.username_label.config(text=f"Username: {self.username}")
            if self.connected and self.websocket:
                payload = {"type": "set_username", "name": self.username}
                asyncio.run_coroutine_threadsafe(self.websocket.send(json.dumps(payload)), self.loop)

    # ---------- Shutdown ----------

    def on_close(self):
        self.stopping = True

        async def shutdown():
            try:
                if self.websocket:
                    await self.websocket.close()
            except:
                pass
            self.loop.stop()

        # Schedule shutdown coroutine
        self.loop.call_soon_threadsafe(asyncio.ensure_future, shutdown())
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    client = ChatClient(root)
    root.mainloop()

