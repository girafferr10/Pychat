import tkinter as tk
from tkinter import ttk
import asyncio
import json

CARD_WIDTH = 50
CARD_HEIGHT = 70

class BlackjackUI:
    def __init__(self, notebook, ws, loop, username="Anonymous", spectator=False):
        self.ws = ws
        self.loop = loop
        self.username = username
        self.spectator = spectator
        self.timeout_seconds = 20

        # Tab
        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text="Blackjack")

        # Theme
        style = ttk.Style()
        style.configure("Casino.TFrame", background="darkgreen")
        style.configure("Casino.TLabel", background="darkgreen", foreground="gold", font=("Arial", 12, "bold"))
        self.frame.configure(style="Casino.TFrame")

        # ---------- GAME AREA (TOP) ----------
        game_frame = ttk.Frame(self.frame, style="Casino.TFrame")
        game_frame.pack(fill="both", expand=True)

        # Dealer
        dealer_label = ttk.Label(game_frame, text="Dealer", style="Casino.TLabel")
        dealer_label.pack(pady=5)
        self.dealer_canvas = tk.Canvas(game_frame, height=CARD_HEIGHT+20, bg="darkgreen", highlightthickness=0)
        self.dealer_canvas.pack(pady=5)

        # Action buttons
        if not self.spectator:
            action_frame = ttk.Frame(game_frame, style="Casino.TFrame")
            action_frame.pack(pady=5)
            ttk.Button(action_frame, text="New Round", command=lambda: self.send_action("new_round")).pack(side="left", padx=5)
            ttk.Button(action_frame, text="Hit", command=lambda: self.send_action("hit")).pack(side="left", padx=5)
            ttk.Button(action_frame, text="Stand", command=lambda: self.send_action("stand")).pack(side="left", padx=5)

        # Players scrollable area
        self.players_canvas = tk.Canvas(game_frame, bg="darkgreen", highlightthickness=0)
        self.players_scroll = ttk.Scrollbar(game_frame, orient="vertical", command=self.players_canvas.yview)
        self.players_frame = ttk.Frame(self.players_canvas, style="Casino.TFrame")

        self.players_frame.bind(
            "<Configure>",
            lambda e: self.players_canvas.configure(scrollregion=self.players_canvas.bbox("all"))
        )

        self.players_canvas.create_window((0,0), window=self.players_frame, anchor="nw")
        self.players_canvas.configure(yscrollcommand=self.players_scroll.set)

        self.players_canvas.pack(side="left", fill="both", expand=True)
        self.players_scroll.pack(side="right", fill="y")

        # ---------- CHAT AREA (BOTTOM) ----------
        chat_frame = ttk.Frame(self.frame)
        chat_frame.pack(fill="x", side="bottom")

        self.chat_area = tk.Text(chat_frame, state="disabled", wrap="word", height=6, bg="black", fg="white")
        self.chat_area.pack(fill="both", expand=True, padx=10, pady=5)

        entry_frame = ttk.Frame(chat_frame)
        entry_frame.pack(fill="x", padx=10, pady=5)
        self.entry = tk.Entry(entry_frame)
        self.entry.pack(side="left", fill="x", expand=True)
        send_btn = ttk.Button(entry_frame, text="Send", command=self.send_chat)
        send_btn.pack(side="right")

        # Close Tab button at bottom
        close_btn = ttk.Button(self.frame, text="Close Tab", command=self.close_tab)
        close_btn.pack(side="bottom", pady=5)

        # Timeout
        self.current_turn_id = None
        self.timeout_job = None

    # ---------- Networking ----------

    def send_chat(self):
        msg = self.entry.get().strip()
        if not msg: return
        self.entry.delete(0, "end")
        payload = {"type": "bj_chat", "text": msg}
        asyncio.run_coroutine_threadsafe(self.ws.send(json.dumps(payload)), self.loop)

    def send_action(self, action):
        payload = {"type": "bj_action", "action": action}
        asyncio.run_coroutine_threadsafe(self.ws.send(json.dumps(payload)), self.loop)

    def handle_server_message(self, data):
        msg_type = data.get("type")
        if msg_type == "bj_chat":
            self.chat_area.config(state="normal")
            self.chat_area.insert("end", f"{data['from']}: {data['text']}\n")
            self.chat_area.config(state="disabled")
            self.chat_area.see("end")

        elif msg_type == "bj_state":
            self.render_state(data["state"])

    # ---------- Rendering ----------

    def render_state(self, state):
        # Dealer hand
        self.dealer_canvas.delete("all")
        dealer_hand = state["dealer_hand"]
        for i, card in enumerate(dealer_hand):
            self.draw_card(self.dealer_canvas, card, 10 + i*(CARD_WIDTH+10), 10)

        # Players
        for widget in self.players_frame.winfo_children():
            widget.destroy()

        for p in state["players"]:
            self.render_player(self.players_frame, p)

        # Timeout handling
        if state["current_player_id"]:
            self.current_turn_id = state["current_player_id"]
            if self.timeout_job:
                self.frame.after_cancel(self.timeout_job)
            self.timeout_job = self.frame.after(self.timeout_seconds*1000, self.auto_timeout)

    def render_player(self, parent, player):
        row = ttk.Frame(parent, style="Casino.TFrame")
        row.pack(fill="x", pady=5)

        # Cards first
        hand_canvas = tk.Canvas(row, height=CARD_HEIGHT+20, width=300, bg="darkgreen", highlightthickness=0)
        hand_canvas.pack()
        for i, card in enumerate(player["hand"]):
            self.draw_card(hand_canvas, card, 10 + i*(CARD_WIDTH+10), 10)

        # Name under cards
        name_lbl = ttk.Label(row, text=player["name"], style="Casino.TLabel")
        name_lbl.pack()

        # Hand value under name
        hand_value = player["value"]
        value_lbl = ttk.Label(row, text=f"Value: {hand_value}", style="Casino.TLabel")
        value_lbl.pack()

        # Status
        status = player["status"]
        winner = player.get("winner")
        status_text = status
        color = "white"
        if winner is True:
            status_text += " → WINNER"
            color = "green"
        elif winner is False:
            status_text += " → LOSE"
            color = "red"
        elif winner == "push":
            status_text += " → PUSH"
            color = "orange"

        status_lbl = ttk.Label(row, text=status_text, foreground=color, background="darkgreen")
        status_lbl.pack()

    def draw_card(self, canvas, card, x, y):
        if card == "??":
            canvas.create_rectangle(x, y, x+CARD_WIDTH, y+CARD_HEIGHT, fill="gray", outline="white")
            canvas.create_text(x+CARD_WIDTH/2, y+CARD_HEIGHT/2, text="??", fill="white", font=("Arial", 14, "bold"))
            return
        rank = card[:-1]
        suit = card[-1]
        color = "red" if suit in ["♥","♦"] else "black"
        canvas.create_rectangle(x, y, x+CARD_WIDTH, y+CARD_HEIGHT, fill="white", outline="black")
        canvas.create_text(x+CARD_WIDTH/2, y+CARD_HEIGHT/2, text=f"{rank}{suit}", fill=color, font=("Arial", 14, "bold"))

        # Animation: flash border
        canvas.after(100, lambda: canvas.create_rectangle(x, y, x+CARD_WIDTH, y+CARD_HEIGHT, outline="gold", width=2))
        canvas.after(300, lambda: canvas.create_rectangle(x, y, x+CARD_WIDTH, y+CARD_HEIGHT, outline="black", width=1))

    def auto_timeout(self):
        if self.current_turn_id:
            payload = {"type": "bj_action", "action": "stand"}
            asyncio.run_coroutine_threadsafe(self.ws.send(json.dumps(payload)), self.loop)

            self.chat_area.config(state="normal")
            self.chat_area.insert("end", f"[SYSTEM] Player {self.current_turn_id} timed out → auto-stand.\n")
            self.chat_area.config(state="disabled")
            self.chat_area.see("end")

            self.current_turn_id = None
            self.timeout_job = None

    def close_tab(self):
        # Placeholder: actual tab closing handled in client.py
        self.frame.destroy()


# Standalone test harness
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Blackjack UI Test")

    loop = asyncio.new_event_loop()
    ws = None  # Replace with actual websocket when integrated

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True)

    # Instantiate the UI for testing
    ui = BlackjackUI(notebook, ws, loop, username="Tester", spectator=False)

    root.mainloop()

