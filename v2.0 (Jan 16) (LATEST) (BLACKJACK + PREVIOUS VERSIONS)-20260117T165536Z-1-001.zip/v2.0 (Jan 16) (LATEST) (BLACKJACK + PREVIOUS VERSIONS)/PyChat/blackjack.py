import random

class BlackjackTable:
    def __init__(self):
        self.players = {}
        self.order = []
        self.dealer_hand = []
        self.deck = []
        self.current_index = 0
        self.in_round = False
        self.websockets_in_table = set()

    def _new_deck(self):
        ranks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
        suits = ["♠","♥","♦","♣"]
        self.deck = [f"{r}{s}" for r in ranks for s in suits]
        random.shuffle(self.deck)

    def _draw(self):
        if not self.deck: self._new_deck()
        return self.deck.pop()

    def _hand_value(self, hand):
        total, aces = 0, 0
        for card in hand:
            rank=card[:-1]
            if rank in ["J","Q","K"]: total+=10
            elif rank=="A": total+=11; aces+=1
            else: total+=int(rank)
        while total>21 and aces>0:
            total-=10; aces-=1
        return total

    def add_player(self, ws, name):
        self.websockets_in_table.add(ws)
        pid=id(ws)
        if pid not in self.players:
            self.players[pid]={"name":name,"hand":[],"ws":ws,"status":"waiting","winner":None}
            self.order.append(pid)

    def remove_websocket(self, ws):
        self.websockets_in_table.discard(ws)
        pid=None
        for p_id,pdata in list(self.players.items()):
            if pdata["ws"] is ws: pid=p_id; break
        if pid:
            self.players.pop(pid,None)
            if pid in self.order: self.order.remove(pid)
            if not self.players: self.reset_table()

    def get_player_id(self, ws):
        for pid,pdata in self.players.items():
            if pdata["ws"] is ws: return pid
        return None

    def reset_table(self):
        self.players.clear(); self.order.clear()
        self.dealer_hand=[]; self.deck=[]
        self.current_index=0; self.in_round=False

    def new_round(self):
        if not self.players: return
        self._new_deck()
        self.dealer_hand=[self._draw(),self._draw()]
        self.in_round=True; self.current_index=0
        for pid in self.order:
            pdata=self.players[pid]
            pdata["hand"]=[self._draw(),self._draw()]
            pdata["status"]="playing"
            pdata["winner"]=None

    def _next_player_index(self,start_index):
        for i in range(start_index+1,len(self.order)):
            pid=self.order[i]
            if self.players[pid]["status"]=="playing": return i
        return None

    def hit(self,pid):
        if not self.in_round or self.order[self.current_index]!=pid: return
        pdata=self.players[pid]
        pdata["hand"].append(self._draw())
        val=self._hand_value(pdata["hand"])
        if val>21:
            pdata["status"]="busted"
            nxt=self._next_player_index(self.current_index)
            if nxt is None: self._dealer_play()
            else: self.current_index=nxt

    def stand(self,pid):
        if not self.in_round or self.order[self.current_index]!=pid: return
        self.players[pid]["status"]="stood"
        nxt=self._next_player_index(self.current_index)
        if nxt is None: self._dealer_play()
        else: self.current_index=nxt

    def _dealer_play(self):
        while self._hand_value(self.dealer_hand)<17:
            self.dealer_hand.append(self._draw())
        self.in_round=False
        self._determine_winners()

    def _determine_winners(self):
        dealer_val=self._hand_value(self.dealer_hand)
        dealer_bust=dealer_val>21
        for pid,pdata in self.players.items():
            val=self._hand_value(pdata["hand"])
            if pdata["status"]=="busted":
                pdata["winner"]=False
            elif dealer_bust or val>dealer_val:
                pdata["winner"]=True
            elif val==dealer_val:
                pdata["winner"]="push"
            else:
                pdata["winner"]=False

    def to_state(self):
        players_state=[]
        for pid in self.order:
            pdata=self.players[pid]
            players_state.append({
                "id":pid,"name":pdata["name"],
                "hand":pdata["hand"],
                "value":self._hand_value(pdata["hand"]),
                "status":pdata["status"],
                "winner":pdata["winner"]
            })
        dealer_value=self._hand_value(self.dealer_hand) if self.dealer_hand else 0
        current=None
        if self.in_round and self.order: current=self.order[self.current_index]

        # Hide dealer’s second card if round still in progress
        dealer_display=self.dealer_hand[:]
        if self.in_round and len(dealer_display)>1:
            dealer_display[1]="??"

        return {
            "in_round":self.in_round,
            "dealer_hand":dealer_display,
            "dealer_value":dealer_value if not self.in_round else None,
            "players":players_state,
            "current_player_id":current
        }

