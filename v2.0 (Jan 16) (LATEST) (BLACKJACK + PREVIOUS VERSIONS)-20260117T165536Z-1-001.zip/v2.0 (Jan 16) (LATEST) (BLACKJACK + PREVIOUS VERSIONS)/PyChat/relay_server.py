# relay_server.py
import asyncio
import json
import websockets
from blackjack import BlackjackTable

connected = set()
usernames = {}
bj_table = BlackjackTable()

print("Running relay_server.py with Blackjack support")

async def broadcast(payload, only_blackjack=False):
    msg = json.dumps(payload)
    to_remove = set()
    for ws in connected:
        if only_blackjack and ws not in bj_table.websockets_in_table:
            continue
        try:
            await ws.send(msg)
        except Exception as e:
            print(f"[!] Error sending to client: {e}")
            to_remove.add(ws)
    for dead in to_remove:
        connected.discard(dead)
        usernames.pop(dead, None)
        bj_table.remove_websocket(dead)

async def handle_global_chat(ws, data):
    text = data.get("text", "").strip()
    if not text: return
    name = usernames.get(ws, "Anonymous")
    await broadcast({"type": "chat","from": name,"text": text})

async def handle_set_username(ws, data):
    name = data.get("name", "").strip() or "Anonymous"
    usernames[ws] = name
    await ws.send(json.dumps({"type":"system","text":f"Username set to {name}"}))

async def handle_bj_join(ws, data):
    name = usernames.get(ws, data.get("name","Anonymous"))
    usernames[ws] = name
    bj_table.add_player(ws, name)
    await broadcast({"type":"bj_state","state":bj_table.to_state()}, only_blackjack=True)

async def handle_bj_chat(ws, data):
    text = data.get("text","").strip()
    if not text: return
    name = usernames.get(ws,"Anonymous")
    await broadcast({"type":"bj_chat","from":name,"text":text}, only_blackjack=True)

async def handle_bj_action(ws, data):
    action = data.get("action")
    if action not in ("hit","stand","new_round"): return
    pid = bj_table.get_player_id(ws)
    if pid is None:
        await ws.send(json.dumps({"type":"bj_error","text":"You are not seated at the table."}))
        return
    if action=="new_round": bj_table.new_round()
    elif action=="hit": bj_table.hit(pid)
    elif action=="stand": bj_table.stand(pid)
    await broadcast({"type":"bj_state","state":bj_table.to_state()}, only_blackjack=True)

async def handler(ws):
    connected.add(ws)
    print(f"[+] Client connected. Total: {len(connected)}")
    try:
        async for raw in ws:
            try: data=json.loads(raw)
            except json.JSONDecodeError: data={"type":"chat","text":raw}
            t=data.get("type")
            if t=="set_username": await handle_set_username(ws,data)
            elif t=="chat": await handle_global_chat(ws,data)
            elif t=="bj_join": await handle_bj_join(ws,data)
            elif t=="bj_chat": await handle_bj_chat(ws,data)
            elif t=="bj_action": await handle_bj_action(ws,data)
            else: print(f"[!] Unknown message type: {t}")
    except Exception as e:
        print(f"[!] Client error: {e}")
    finally:
        print("[-] Client disconnected")
        connected.discard(ws)
        usernames.pop(ws,None)
        bj_table.remove_websocket(ws)

async def main():
    print("Relay server running on 0.0.0.0:8765 with Blackjack")
    async with websockets.serve(handler,"0.0.0.0",8765):
        await asyncio.Future()

if __name__=="__main__":
    asyncio.run(main())

